package com.bhsc.mobile.discuss.detail;

import com.bhsc.mobile.datalcass.Data_DB_Discuss;

import java.util.List;

/**
 * Created by lynn on 15-10-10.
 */
public class DiscussEvent {
    private List<Data_DB_Discuss> discusses;

    public List<Data_DB_Discuss> getDiscusses() {
        return discusses;
    }

    public void setDiscusses(List<Data_DB_Discuss> discusses) {
        this.discusses = discusses;
    }
}

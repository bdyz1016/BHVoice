package com.android.pc.ioc.invoker;


public class InjectAlls extends InjectInvoker{

	@Override
    public void invoke(Object beanObject, Object... args) {
    }
}

package com.android.pc.ioc.view;
/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2014-3-11
 * Copyright @ 2014 BU
 * Description: 类描述
 *
 * History:
 */
public class RefershEntity {

	private int type;
	
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}

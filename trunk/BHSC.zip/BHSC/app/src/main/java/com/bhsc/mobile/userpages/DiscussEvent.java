package com.bhsc.mobile.userpages;

import com.bhsc.mobile.datalcass.Data_DB_Discuss;

import java.util.List;

/**
 * Created by lynn on 15-10-9.
 */
public class DiscussEvent {
    List<Data_DB_Discuss> discusses;

    public List<Data_DB_Discuss> getDiscusses() {
        return discusses;
    }

    public void setDiscusses(List<Data_DB_Discuss> discusses) {
        this.discusses = discusses;
    }
}

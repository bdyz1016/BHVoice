package com.android.pc.ioc.util;
/*
 * Author: Administrator Email:gdpancheng@gmail.com
 * Created Date:2014-6-19
 * Copyright @ 2014 BU
 * Description: 类描述
 *
 * History:
 */
public class TimeEntity {

}

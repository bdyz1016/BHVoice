package com.android.pc.ioc.invoker;


public abstract class InjectInvoker {

	public abstract void invoke(Object beanObject,Object... args);
}

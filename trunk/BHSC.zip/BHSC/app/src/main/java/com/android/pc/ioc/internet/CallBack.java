package com.android.pc.ioc.internet;
/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-18
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public interface CallBack {
	public void callBack(ResponseEntity status);
}

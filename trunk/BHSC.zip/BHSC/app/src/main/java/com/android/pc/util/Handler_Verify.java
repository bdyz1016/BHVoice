package com.android.pc.util;
/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2014-2-12
 * Copyright @ 2014 BU
 * Description: 类描述
 *
 * History:
 */
public class Handler_Verify {

	//判断是否是http网络请求
	public final static String http = "[a-zA-z]+://[^\\s]*";
	
}

package com.bhsc.mobile.userpages;

import android.app.Activity;

import com.android.pc.ioc.inject.InjectLayer;
import com.bhsc.mobile.R;

/**
 * Created by lynn on 10/15/15.
 */
@InjectLayer(R.layout.activity_agreement)
public class AgreementActivity extends Activity {
}
